// Require necessary packages
const express = require('express');
const mysql = require('mysql');

// Create a connection to the database
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  database: 'login'
});

// Create an Express application
const app = express();

// Configure the route for handling the login form submission
app.post('/index', (req, res) => {
  const username = req.body.uname;
  const password = req.body.psw;

  // Perform a database query to check the credentials
  const query = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;
  connection.query(query, (error, results, fields) => {
    if (error) throw error;
    if (results.length > 0) {
      // User authenticated, redirect to the home page or do further processing
      res.redirect('/index');
    } else {
      // Invalid credentials, redirect back to the login page
      res.redirect('/login');
    }
  });
});





// Start the server
app.listen(3000, function () {
    console.log('App listening on port 3000!');
   });
   