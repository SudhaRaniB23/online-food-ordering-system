var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
var modal = document.getElementById('id02');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
let cartItems = [];

function addToCart(itemName, price) {
  cartItems.push({ name: itemName, price: price });
  updateCart();
}

function updateCart() {
  const cartList = document.getElementById('cart-items');
  cartList.innerHTML = '';

  let totalPrice = 0;

  for (let i = 0; i < cartItems.length; i++) {
    const item = cartItems[i];

    const listItem = document.createElement('li');
    listItem.innerHTML = `${item.name} - $${item.price}`;
    cartList.appendChild(listItem);

    totalPrice += item.price;
  }

  const checkoutButton = document.getElementById('checkout');
  checkoutButton.innerHTML = `Checkout - Total: $${totalPrice.toFixed(2)}`;
}

function checkout() {
    // Simulating order processing
    setTimeout(function() {
      alert('Thank you for your order! proceed for payment');
      cartItems = [];
      updateCart();
    }, 2000); // 2-second delay to simulate order processing
    
 }
 
 
