const express = require('express');
const mysql = require('mysql');
const app = express();
app.use(express.static("public"));  
app.use(express.urlencoded({ extended: false }));//parses URL-encoded data
app.set("view engine","ejs");

// Create a MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  database: 'login'
});

// Connect to the database
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to the database: ', err);
    return;
  }
  console.log('Connected to the database!');
});
// Set up a route to handle the login request
app.post('/login', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  // Perform a database query to validate the user
  const query = "SELECT * FROM users WHERE username = ? AND password = ?";
  connection.query(query, [username,password], (err, results) => {
    if (err) {
      console.error('Error executing the query: ', err);
      res.sendStatus(500);
      return;
    }

    if (results.length > 0) {
      // User found, redirect to payment details page
      res.redirect('/payment-details.html');
    } else {
      // Invalid credentials, display an error message
      res.send('Invalid username or password');
    }
  });
});

app.post('/index', (req, res) => {
  const username = req.body.uname;
  const password = req.body.psw;

  // Perform a database query to check the credentials
  const query = "SELECT * FROM users WHERE username = ? AND password =?";
  connection.query(query, [username,password],(error, results) => {
    if (error) throw error;
    if (results.length > 0) {
      // User authenticated, redirect to the home page or do further processing
      res.redirect('/index');
    } else {
      // Invalid credentials, redirect back to the login page
      res.redirect('/login');
    }
  });
});
//insertion
app.post('/insert', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  console.log(username);

  // Perform a database query to insert the user
  const query = "INSERT INTO users (username, password) VALUES (?, ?)";
  connection.query(query, [username, password], (err, results) => {
    if (err) {
      console.error('Error executing the query: ', err);
      res.status(500).send('Error inserting user');
      return;
    }
    console.log('User inserted successfully');
    //res.send('User inserted successfully');
    res.render('home');
  });
});
//update
app.post('/update', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  // Perform a database query to update the user
  const query = "UPDATE users SET password = ? WHERE username = ?";
  connection.query(query, [password, username], (err, results) => {
    if (err) {
      console.error('Error executing the query: ', err);
      res.sendStatus(500);
      return;
    }
    res.render('update');
  });
});


//search
app.get('/search/:username', (req, res) => {
  const username = req.params.username;

  // Perform a database query to search for the user
  const query = "SELECT * FROM users WHERE username = ?";
  connection.query(query, [username], (err, results) => {
    if (err) {
      console.error('Error executing the query: ', err);
      res.sendStatus(500);
      return;
    }
    //res.json(results);
    res.render('search');
  });
});


//display
app.get('/display', (req, res) => {
  // Perform a database query to retrieve all users
  const query = "SELECT * FROM users";
  connection.query(query, (err, results) => {
    if (err) {
      console.error('Error executing the query: ', err);
      res.sendStatus(500);
      return;
    }
    
    // Prepare the HTML table
    let tableHTML = '<table><tr><th>Username</th><th>Password</th></tr>';

    // Iterate over the results and add rows to the table
    results.forEach((user) => {
      tableHTML += `<tr><td>${user.username}</td><td>${user.password}</td></tr>`;
    });

    tableHTML += '</table>';

    // Send the HTML table as the response
    res.send(tableHTML);
  });
  
});
 
// Start the server
app.listen(8000, function () {
  console.log('App listening on port 8000!');
 });
 